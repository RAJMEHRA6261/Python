let prompt=document.querySelector(".prompt")
let container=document.querySelector(".container")
let chatContainer=document.querySelector(".chat-container")
let btn=document.querySelector(".btn")
let userMessage=null

const Api_url='https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyDzeVnlJvUvfLzOA8FPTmax0YAKDd3nriI'
//const Api_url=paste here your api url , you can watch it on my video
function createChatBox(html,className){
const div=document.createElement("div")
div.classList.add(className)
div.innerHTML=html;
return div
}
async function generateApiResponse(aiChatBox){
const textElement=aiChatBox.querySelector(".text")
try{
const response=await fetch(Api_url,{
  method:"POST",
  headers:{"Content-Type": "application/json"},
  body:JSON.stringify({
    contents:[{
      "role": "user",
      "parts":[{text:`${userMessage} in 10 words`}]
    }]
  })
})
const data=await response.json()
const apiResponse=data?.candidates[0].content.parts[0].text.trim();
textElement.innerText=apiResponse
if (document.getElementById("voiceToggle").checked) {
  speakText(apiResponse);
}

}
catch(error){
  console.log(error)
}
finally{
  aiChatBox.querySelector(".loading").style.display="none"
}
}
function showLoading(){
  const html=` <div id="img">
        <img src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Google_Gemini_logo.svg" alt="">
    </div>
    <div class="text">
    </div>
    <img src="loading.gif" alt="" height="50" class="loading">`
    let aiChatBox=createChatBox(html,"ai-chat-box")
 chatContainer.appendChild(aiChatBox)
generateApiResponse(aiChatBox)

}

btn.addEventListener("click",()=>{
    userMessage=prompt.value;
    if(prompt.value=""){
      container.style.display="flex"
    }else{
       container.style.display="none"
    }
    if(!userMessage)return;
  const html=` <div id="img">
        <img src="user.png" alt="">
    </div>
    <div class="text">
    </div>`
 let userChatBox=createChatBox(html,"user-chat-box")
 userChatBox.querySelector(".text").innerText=userMessage
 chatContainer.appendChild(userChatBox)
 prompt.value=""
 setTimeout(showLoading,500)

})

document.body.addEventListener('keypress',(e) =>{
  if(e.key == 'Enter')
    {userMessage=prompt.value;
      if(prompt.value=""){
        container.style.display="flex"
      }else{
         container.style.display="none"
      }
      if(!userMessage)return;
    const html=` <div id="img">
          <img src="user.png" alt="">
      </div>
      <div class="text">
      </div>`
   let userChatBox=createChatBox(html,"user-chat-box")
   userChatBox.querySelector(".text").innerText=userMessage
   chatContainer.appendChild(userChatBox)
   prompt.value=""
   setTimeout(showLoading,500)
  }
})
function startVoiceInput() {
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = "en-US";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.start();

  recognition.onresult = function(event) {
    const transcript = event.results[0][0].transcript;
    prompt.value = transcript;
    sendMessage(); // Calls your existing function
  };

  recognition.onerror = function(event) {
    console.error("Speech recognition error:", event.error);
    alert("Voice input failed. Please try again.");
  };
}
function speakText(text) {
  const synth = window.speechSynthesis;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-US";
  utterance.rate = 1;  // Speed: 0.5 (slow) to 2 (fast)
  utterance.pitch = 1; // Pitch: 0 (low) to 2 (high)
  synth.speak(utterance);
}